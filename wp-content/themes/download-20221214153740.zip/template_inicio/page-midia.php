<?php
/**
 * local da documantação
 */
get_header();
?>
<h3 class="text-center mt-3 mb-3">Galeria de Imagens</h3>
<div class="container-imagens">
<?php 

$gallery_image = new WP_Query(array(
	'post_type'=>'attachment', 
	'post_status'=>'inherit', 
	'posts_per_page'=>-1
	));

if ( $gallery_image->have_posts() ) : while( $gallery_image->have_posts()  ) : $gallery_image->the_post(); ?>


	<div class="imagens-itens"><?php echo get_image_tag( get_the_ID(), 'teste', 'teste2', 'teste3', 'medium'); ?></div>

	
<?php endwhile; endif; ?>
</div>	

</div>




<?php
get_footer();
?>