
jQuery(document).ready(function(){
    $('.owl-carousel').owlCarousel({
    center: true,   
    loop:true,
    margin:10,
    nav:true,
    items:2,
    autoplay:true,
    autoplayTimeout:5000,
    autoplayHoverPause:true,
    dots: false
})

  });
  
