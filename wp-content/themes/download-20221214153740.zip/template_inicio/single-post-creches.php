<?php
/**
 * local da documantação
 */
get_header();
?>
<?php if ( have_posts() ) : while( have_posts()  ) : the_post(); ?>

<div class="image-main mx-auto mt-3git">
            <?php the_post_thumbnail('mediun'); ?>
            <div class="post-title text-center">
            <?php the_title(); ?>
        </div>
        </div>
<div class=single-content>
    <div class="single-post">
                <div class="post-content">
            <?php the_content(); ?>
        </div>
    </div>
    <?php endwhile; endif; ?>

    <div class="single-sidebar">
<h4> Noticias, Artigos e afins </h4>
<?php 
      $args = array(
        'cat' => 14, 6,
               'posts_per_page' => 12,
    );
    $blog = new WP_Query($args);
    if ($blog->have_posts()) :
        while ($blog->have_posts()) :
            $blog->the_post();
            ?>
           <span class ="date-sidebar"> <?php the_date('d-m-Y');?></span> - 
            <span class = "title-sidebar"> <a href="<?php echo get_permalink();?>"><?php the_title();?></a></span> <br>
           <span class = "category-sidebar"> <?php the_category( ' ');?></span><br>
           <?php
        endwhile;
        
        wp_reset_postdata();
    endif;
    ?>
        </div>
    
    </div>




<?php
get_footer();
?>