<!-- WPDM Link Template: Default Template ( Old ) -->


<div class="wpdm-link-template link-template-default" >

    <div class="media">
        <div class="mr-3">[icon]</div>
        <div class="media-body">
            <div>
                <strong class="package-title">[title]</strong> | [file_size]
            </div>
            [download_link]
        </div>

    </div>
    <div style="clear: both"></div>
</div>
<div style="clear: both"></div>

