<!-- WPDM Link Template: Default Template with Download Count -->


<div class="wpdm-link-tpl link-btn [color]" data-durl="[download_url]" >
    <div class="media">
        <div class="pull-left">[icon]</div>
        <div class="media-body"><strong class="ptitle">[title] <span class="label label-default" style="font-weight: 400;">[download_count] [txt=downloads]</span>&nbsp;<span class="label label-default" style="font-weight: 400;">[file_size]</span></strong>
            <div><strong>[download_link_extended]</strong></div>
        </div>
    </div>
</div>
<div style="clear: both"></div>
